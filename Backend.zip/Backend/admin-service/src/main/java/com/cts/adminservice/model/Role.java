package com.cts.adminservice.model;

public enum Role {
	CUSTOMER,ADMIN;
}
