package com.cts.userauthservice.model;

public enum Role {
	CUSTOMER,ADMIN;
}
