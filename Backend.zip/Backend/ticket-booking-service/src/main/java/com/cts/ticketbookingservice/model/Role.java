package com.cts.ticketbookingservice.model;

public enum Role {
	CUSTOMER,ADMIN;
}
