export interface show{
    id:string,
    name:string,
    location:string,
    showTime:string,
    totalSeats:number,
    bookedSeats:number,
}