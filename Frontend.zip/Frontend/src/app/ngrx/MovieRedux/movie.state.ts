import { MovieState } from "./movie.reducer";

export interface MovieAppState{
    movie:MovieState
}